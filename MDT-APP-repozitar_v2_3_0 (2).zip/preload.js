const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('redline', {
    setIgnore: (v) => ipcRenderer.send('set-ignore', !!v),
    // klik kamkoliv do mobilu / dispečinku / menu = overlay dostane zaměření (popředí) i vstup z klávesnice
    focus: () => ipcRenderer.send('focus-overlay'),
    onHotkey: (cb) => ipcRenderer.on('hotkey', (e, name) => cb(name)),
    // zkratky nastavené na webu (menu, vysílačka, mobil, dispečink, vysílání) - aplikace je zachytává globálně i ve hře
    setHotkeys: (keys) => ipcRenderer.send('set-hotkeys', keys),
    globalKeys: !!ipcRenderer.sendSync('hook-status'),
    quit: () => ipcRenderer.send('quit'),
    // režimy: okno aplikace (celý web) a overlay
    getMode: () => ipcRenderer.invoke('mode:get'),
    setApp: (on) => ipcRenderer.invoke('mode:app', !!on),
    setOverlay: (on) => ipcRenderer.invoke('mode:overlay', !!on),
    onMode: (cb) => ipcRenderer.on('mode', (e, m) => cb(m)),
});
