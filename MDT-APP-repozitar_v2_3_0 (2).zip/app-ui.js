(function () {
    'use strict';
    const $ = (id) => document.getElementById(id);
    const api = window.redlineApp;
    let hasSaved = false, savedUser = '', encOk = true;

    function show(state) {
        const on = !!(state && state.loggedIn);
        $('view-login').hidden = on;
        $('view-run').hidden = !on;
        $('b-quit2').hidden = on;
        $('badge').classList.toggle('on', on);
        $('badge-text').textContent = on ? 'Overlay běží' : 'Nepřihlášen';
        if (state && state.siteUrl) $('site').textContent = state.siteUrl.replace(/^https?:\/\//, '');
        if (on) $('who').textContent = state.username || '';
        const note = $('note');
        note.hidden = !(state && state.notice && !on);
        note.textContent = (state && state.notice) || '';
        showUpdate(state);
        if (!on) { $('go').disabled = false; $('go').textContent = 'Přihlásit se'; $('p').focus(); }
    }

    function showUpdate(state) {
        const u = state && state.update;
        $('upd').hidden = !u;
        if (!u) return;
        if (u.status === 'ready') { $('upd-text').textContent = 'Nová verze ' + u.version + ' je připravená.'; $('b-upd').hidden = false; }
        else { $('upd-text').textContent = 'Stahuji novou verzi ' + u.version + ' (' + (u.percent || 0) + ' %)…'; $('b-upd').hidden = true; }
    }

    function setErr(msg) { const e = $('err'); e.hidden = !msg; e.textContent = msg || ''; }

    function applyPasswordHint() {
        const same = $('u').value.trim().toLowerCase() === savedUser.toLowerCase();
        $('p').placeholder = (hasSaved && same) ? '•••••••• (uložené heslo)' : '';
    }

    $('view-login').addEventListener('submit', async (ev) => {
        ev.preventDefault();
        setErr('');
        $('go').disabled = true; $('go').textContent = 'Přihlašuji…';
        const r = await api.login({ username: $('u').value, password: $('p').value, remember: $('remember').checked });
        if (!r || !r.ok) {
            $('go').disabled = false; $('go').textContent = 'Přihlásit se';
            setErr((r && r.error) || 'Přihlášení se nezdařilo.');
        } else {
            $('p').value = '';
        }
    });
    $('u').addEventListener('input', applyPasswordHint);

    $('b-toggle').addEventListener('click', () => api.toggleOverlay());
    $('b-phone').addEventListener('click', () => api.hotkey('phone'));
    $('b-disp').addEventListener('click', () => api.hotkey('disp'));
    $('b-min').addEventListener('click', () => api.minimize());
    $('b-out').addEventListener('click', () => api.logout());
    $('b-quit').addEventListener('click', () => api.quit());
    $('b-quit2').addEventListener('click', () => api.quit());
    $('b-upd').addEventListener('click', () => api.installUpdate());

    api.onState((s) => { setErr(''); show(s); });
    api.init().then((i) => {
        savedUser = i.username || ''; hasSaved = !!i.hasSavedPassword; encOk = !!i.canEncrypt;
        $('u').value = savedUser;
        $('remember').checked = true;
        $('ver').textContent = 'verze ' + i.version;
        if (!encOk) $('login-hint').textContent = 'Heslo nelze na tomhle počítači bezpečně uložit – pamatuje se jen uživatelské jméno.';
        applyPasswordHint();
        show(i.state);
        if (savedUser) $('p').focus(); else $('u').focus();
    });
})();
