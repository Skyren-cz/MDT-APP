const { contextBridge, ipcRenderer } = require('electron');
// Rozhraní pro okno aplikace (celý web): zapnutí / vypnutí overlaye a okna aplikace.
contextBridge.exposeInMainWorld('rlApp', {
    getMode: () => ipcRenderer.invoke('mode:get'),
    setOverlay: (on) => ipcRenderer.invoke('mode:overlay', !!on),
    setApp: (on) => ipcRenderer.invoke('mode:app', !!on),
    installUpdate: () => ipcRenderer.send('app:install-update'),
    onMode: (cb) => ipcRenderer.on('mode', (e, m) => cb(m)),
});
