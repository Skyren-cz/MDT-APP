const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('redlineApp', {
    init: () => ipcRenderer.invoke('app:init'),
    login: (data) => ipcRenderer.invoke('app:login', data),
    forget: () => ipcRenderer.invoke('app:forget'),
    logout: () => ipcRenderer.send('app:logout'),
    toggleOverlay: () => ipcRenderer.send('app:toggle-overlay'),
    hotkey: (name) => ipcRenderer.send('app:hotkey', name),
    minimize: () => ipcRenderer.send('app:minimize'),
    quit: () => ipcRenderer.send('app:quit'),
    installUpdate: () => ipcRenderer.send('app:install-update'),
    onState: (cb) => ipcRenderer.on('state', (e, s) => cb(s)),
});
