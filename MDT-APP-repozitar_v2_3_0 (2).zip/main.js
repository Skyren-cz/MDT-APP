/* RedLine MDT APP 2.1
 *
 * - Hlavní okno aplikace (ikona na hlavním panelu Windows) = přihlášení + ovládání. Po každém spuštění
 *   je nutné se přihlásit; jméno a heslo z minula jsou předvyplněné (heslo je uložené zašifrovaně
 *   přes Windows DPAPI / Electron safeStorage jen na tomto počítači).
 * - Po přihlášení se otevře OKNO APLIKACE = celý web jako v prohlížeči (bez overlaye). Overlay se zapíná až tam,
 *   v menu (sekce „Aplikace“ → Zapnout overlay). Pak jde okno aplikace vypínat / zapínat zvlášť:
 *     jen aplikace   – křížek okna aplikaci ukončí
 *     aplikace + overlay / jen overlay – křížek okno jen schová; ukončení je v menu overlaye („Ukončit aplikaci“) nebo v liště
 * - Overlay je průhledný přes celou obrazovku (overlay.php): MOBIL = celý web
 *   kromě dispečinku, DISPEČINK = vlastní okno. Kliknutí propouští do hry všude mimo tato okna.
 *   Globální klávesy: F7 = ukázat / skrýt overlay. Ostatní zkratky (mobil, dispečink, menu, vysílačka a VYSÍLÁNÍ klávesou
 *   nebo tlačítkem myši) si nastavuje web v Nastavení a aplikace je zachytává globálně (uiohook-napi) i když je v popředí hra.
 * Nic se nevkládá do žádné jiné aplikace ani do hry - je to obyčejné samostatné okno.
 */
const { app, BrowserWindow, globalShortcut, ipcMain, Menu, Tray, nativeImage, screen, session, shell, dialog, safeStorage } = require('electron');
const fs = require('fs');
const IS_LINUX = process.platform === 'linux';
let autoUpdater = null;
try { ({ autoUpdater } = require('electron-updater')); } catch (e) { autoUpdater = null; }
let uIOhook = null, UiohookKey = null;
try { ({ uIOhook, UiohookKey } = require('uiohook-napi')); } catch (e) { uIOhook = null; }   // bez něj fungují jen F7/F8/F9
const path = require('path');

const DEFAULT_SITE = 'https://databaze-redline.infinityfreeapp.com';
const PARTITION = 'persist:redline';

let siteUrl = DEFAULT_SITE;
let overlay = null;
let webWin = null;       // okno aplikace (celý web)
let controlWin = null;
let tray = null;
let overlayVisible = true;
let quitting = false;
let loginBusy = false;
if (IS_LINUX) app.commandLine.appendSwitch('no-sandbox');   // AppImage / Ubuntu 24.04 bez nastavení sandboxu jinak aplikace nenaběhne (načítá jen náš web)
const state = { loggedIn: false, username: '', notice: '', update: null };
const overlayOn = () => !!(overlay && !overlay.isDestroyed());
const webOn = () => !!(webWin && !webWin.isDestroyed());
const webShown = () => webOn() && webWin.isVisible();

/* ---------- automatické aktualizace (GitHub Releases, jako u Discordu) ---------- */
function setupUpdater() {
    if (!autoUpdater || !app.isPackaged) return;      // jen v nainstalované aplikaci
    autoUpdater.autoDownload = true;                  // stáhne na pozadí
    autoUpdater.autoInstallOnAppQuit = true;          // a nainstaluje při ukončení aplikace
    autoUpdater.logger = null;
    autoUpdater.on('update-available', (i) => { state.update = { status: 'downloading', version: i.version, percent: 0 }; pushState(); });
    autoUpdater.on('download-progress', (p) => { if (state.update) { state.update.percent = Math.round(p.percent); pushState(); } });
    autoUpdater.on('update-downloaded', (i) => { state.update = { status: 'ready', version: i.version }; pushState(); });
    autoUpdater.on('error', () => { /* bez internetu / bez vydání - zkusí se znovu */ });
    const check = () => { autoUpdater.checkForUpdates().catch(() => {}); };
    setTimeout(check, 5000);
    setInterval(check, 30 * 60 * 1000);
}
function installUpdate() { if (autoUpdater && state.update && state.update.status === 'ready') { quitting = true; autoUpdater.quitAndInstall(false, true); } }

/* ---------- globální zkratky (klávesy i tlačítka myši) ---------- */
let hookOk = false;
let hotkeys = { phone: 'F8', win: 'F9', menu: 'F6', radio: 'F10', ptt: 'KeyB' };   // přepíše web přes set-hotkeys
const ACTION_NAME = { phone: 'phone', win: 'disp', menu: 'menu', radio: 'radio' };
const pressed = new Set();     // proti opakování při držení klávesy
const pttHeldBy = { token: null };

// DOM KeyboardEvent.code -> kód klávesy uiohook
function codeToKeycode(code) {
    if (!UiohookKey || typeof code !== 'string') return undefined;
    let m;
    if ((m = /^Key([A-Z])$/.exec(code))) return UiohookKey[m[1]];
    if ((m = /^Digit(\d)$/.exec(code))) return UiohookKey[m[1]];
    if ((m = /^F(\d{1,2})$/.exec(code))) return UiohookKey['F' + m[1]];
    if ((m = /^Numpad(\d)$/.exec(code))) return UiohookKey['Numpad' + m[1]];
    const map = {
        Space: 'Space', Tab: 'Tab', CapsLock: 'CapsLock', Enter: 'Enter', Backspace: 'Backspace', Escape: 'Escape',
        Backquote: 'Backquote', Minus: 'Minus', Equal: 'Equal', BracketLeft: 'BracketLeft', BracketRight: 'BracketRight',
        Backslash: 'Backslash', Semicolon: 'Semicolon', Quote: 'Quote', Comma: 'Comma', Period: 'Period', Slash: 'Slash',
        Insert: 'Insert', Delete: 'Delete', Home: 'Home', End: 'End', PageUp: 'PageUp', PageDown: 'PageDown',
        ArrowUp: 'ArrowUp', ArrowDown: 'ArrowDown', ArrowLeft: 'ArrowLeft', ArrowRight: 'ArrowRight',
        ControlLeft: 'Ctrl', ControlRight: 'CtrlRight', AltLeft: 'Alt', AltRight: 'AltRight', ShiftLeft: 'Shift', ShiftRight: 'ShiftRight',
        NumpadAdd: 'NumpadAdd', NumpadSubtract: 'NumpadSubtract', NumpadMultiply: 'NumpadMultiply', NumpadDivide: 'NumpadDivide',
        NumpadDecimal: 'NumpadDecimal', NumpadEnter: 'NumpadEnter', PrintScreen: 'PrintScreen', ScrollLock: 'ScrollLock',
    };
    return map[code] ? UiohookKey[map[code]] : undefined;
}
// DOM MouseEvent.button (1 střední, 3 zpět, 4 vpřed) -> uiohook (3, 4, 5)
const DOM_TO_UIO_MOUSE = { 1: 3, 3: 4, 4: 5 };
function tokenOf(code) {
    let m;
    if ((m = /^Mouse(\d)$/.exec(code || ''))) return DOM_TO_UIO_MOUSE[Number(m[1])] ? 'm' + DOM_TO_UIO_MOUSE[Number(m[1])] : null;
    const kc = codeToKeycode(code);
    return kc == null ? null : 'k' + kc;
}
function onPress(token) {
    if (pressed.has(token)) return;       // držení klávesy = jen první stisk
    pressed.add(token);
    if (!state.loggedIn) return;
    if (token === tokenOf(hotkeys.ptt)) { pttHeldBy.token = token; sendHotkey('ptt-down'); return; }
    for (const k of Object.keys(ACTION_NAME)) { if (token === tokenOf(hotkeys[k])) { sendHotkey(ACTION_NAME[k]); return; } }
}
function onRelease(token) {
    pressed.delete(token);
    if (pttHeldBy.token === token) { pttHeldBy.token = null; sendHotkey('ptt-up'); }
}
function startHook() {
    if (!uIOhook || hookOk) return;
    try {
        uIOhook.on('keydown', (e) => onPress('k' + e.keycode));
        uIOhook.on('keyup', (e) => onRelease('k' + e.keycode));
        uIOhook.on('mousedown', (e) => onPress('m' + e.button));
        uIOhook.on('mouseup', (e) => onRelease('m' + e.button));
        uIOhook.start();
        hookOk = true;
    } catch (e) { hookOk = false; }
}

/* ---------- konfigurace ---------- */
function configPath() { return path.join(app.getPath('userData'), 'config.json'); }
function loadConfig() {
    const read = (file) => {
        try {
            const c = JSON.parse(fs.readFileSync(file, 'utf8'));
            if (c && typeof c.siteUrl === 'string' && /^https?:\/\//.test(c.siteUrl)) siteUrl = c.siteUrl.replace(/\/+$/, '');
        } catch (e) { /* bez souboru / první spuštění */ }
    };
    read(configPath());
    read(path.join(path.dirname(process.execPath), 'config.json')); // vedle programu (snadná změna adresy)
}
const overlayUrl = () => siteUrl + '/overlay.php';
const loginUrl = () => siteUrl + '/auth/login.php';
const partitionSession = () => session.fromPartition(PARTITION);

/* ---------- uložené přihlašovací údaje ---------- */
function credsPath() { return path.join(app.getPath('userData'), 'credentials.json'); }
function canEncrypt() { try { return safeStorage.isEncryptionAvailable(); } catch (e) { return false; } }
function loadCreds() {
    try {
        const c = JSON.parse(fs.readFileSync(credsPath(), 'utf8'));
        let password = '';
        if (c.pw && canEncrypt()) {
            try { password = safeStorage.decryptString(Buffer.from(c.pw, 'base64')); } catch (e) { password = ''; }
        }
        return { username: String(c.username || ''), password };
    } catch (e) { return { username: '', password: '' }; }
}
function saveCreds(username, password) {
    const o = { username };
    if (canEncrypt()) o.pw = safeStorage.encryptString(password).toString('base64');
    fs.writeFileSync(credsPath(), JSON.stringify(o));
}
function clearCreds() { try { fs.unlinkSync(credsPath()); } catch (e) { /* nebylo co mazat */ } }

/* ---------- hlavní okno (hlavní panel) ---------- */
function modeInfo() {
    return { overlay: overlayOn(), app: webShown(), username: state.username, version: app.getVersion(), update: state.update };
}
function pushMode() {
    const m = modeInfo();
    [webWin, overlay].forEach((w) => { if (w && !w.isDestroyed()) w.webContents.send('mode', m); });
    refreshTray();
}
function pushState() {
    if (controlWin && !controlWin.isDestroyed()) controlWin.webContents.send('state', { ...state, siteUrl });
    pushMode();
}

function createControl() {
    controlWin = new BrowserWindow({
        width: 460, height: 640, title: 'RedLine MDT APP', autoHideMenuBar: true, resizable: false, maximizable: false,
        backgroundColor: '#0b1020', icon: path.join(__dirname, 'icon.png'), show: false,
        webPreferences: { preload: path.join(__dirname, 'preload-app.js'), contextIsolation: true, nodeIntegration: false, sandbox: true },
    });
    controlWin.setMenu(null);
    controlWin.loadFile(path.join(__dirname, 'app.html'));
    controlWin.once('ready-to-show', () => controlWin.show());
    controlWin.webContents.setWindowOpenHandler(({ url }) => { shell.openExternal(url); return { action: 'deny' }; });
    // Okno přihlášení: křížek aplikaci ukončí (overlay ještě neběží).
    controlWin.on('close', () => { if (!quitting) { quitting = true; app.quit(); } });
    controlWin.on('closed', () => { controlWin = null; });
}

/** Okno, které má být vidět: po přihlášení okno aplikace, jinak přihlášení. */
function showMain() { state.loggedIn ? showWeb() : showControl(); }

function showControl() {
    if (!controlWin || controlWin.isDestroyed()) { createControl(); return; }
    if (controlWin.isMinimized()) controlWin.restore();
    controlWin.show();
    controlWin.focus();
}

/* ---------- přihlášení přes skutečné okno prohlížeče (kvůli ochraně hostingu) ---------- */
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
function waitForLoad(wc, ms) {
    return new Promise((resolve, reject) => {
        const done = () => { cleanup(); resolve(); };
        const fail = (e, code, desc) => { cleanup(); reject(new Error(desc || 'načtení selhalo')); };
        const t = setTimeout(() => { cleanup(); reject(new Error('časový limit')); }, ms);
        function cleanup() { clearTimeout(t); wc.removeListener('did-finish-load', done); wc.removeListener('did-fail-load', fail); }
        wc.on('did-finish-load', done); wc.on('did-fail-load', fail);
    });
}

async function webLogin(username, password) {
    const w = new BrowserWindow({ show: false, width: 700, height: 800, webPreferences: { partition: PARTITION, contextIsolation: true, nodeIntegration: false } });
    const wc = w.webContents;
    const js = (code) => wc.executeJavaScript(code, true);
    try {
        wc.loadURL(loginUrl()).catch(() => {});
        // Hosting může nejdřív vrátit kontrolní stránku a teprve pak formulář - počkáme na něj.
        let hasForm = false;
        for (let i = 0; i < 40 && !hasForm; i++) {
            await sleep(400);
            try { hasForm = await js("!!document.querySelector('form.login-form input[name=username]')"); } catch (e) { hasForm = false; }
        }
        if (!hasForm) return { ok: false, error: 'Přihlašovací stránka se nenačetla. Zkontroluj připojení a adresu webu (' + siteUrl + ').' };

        const loaded = waitForLoad(wc, 25000);
        await js(
            "(function(){var f=document.querySelector('form.login-form');" +
            'f.elements.username.value=' + JSON.stringify(username) + ';' +
            'f.elements.password.value=' + JSON.stringify(password) + ';f.submit();})()'
        );
        await loaded;
        await sleep(300);
        let stillForm = true;
        try { stillForm = await js("!!document.querySelector('form.login-form')"); } catch (e) { stillForm = false; }
        if (stillForm) {
            let err = '';
            try { err = await js("((document.querySelector('.login-error')||{}).textContent||'')"); } catch (e) { /* nic */ }
            return { ok: false, error: (err || '').trim() || 'Přihlášení se nezdařilo.' };
        }
        return { ok: true };
    } catch (e) {
        return { ok: false, error: 'Přihlášení se nezdařilo: ' + e.message };
    } finally {
        if (!w.isDestroyed()) w.destroy();
    }
}

async function doLogin({ username, password, remember }) {
    if (loginBusy) return { ok: false, error: 'Přihlašování už probíhá…' };
    username = String(username || '').trim();
    password = String(password || '');
    if (!password && username) { // heslo nechané prázdné = použij uložené
        const saved = loadCreds();
        if (saved.username.toLowerCase() === username.toLowerCase()) password = saved.password;
    }
    if (!username || !password) return { ok: false, error: 'Vyplň uživatelské jméno i heslo.' };
    loginBusy = true;
    try {
        const r = await webLogin(username, password);
        if (!r.ok) return r;
        if (remember) saveCreds(username, password); else clearCreds();
        state.loggedIn = true; state.username = username; state.notice = '';
        createWebWindow();
        if (controlWin && !controlWin.isDestroyed()) controlWin.destroy();
        controlWin = null;
        pushState();
        return { ok: true };
    } finally { loginBusy = false; }
}

async function doLogout(notice) {
    if (!state.loggedIn) return;
    state.loggedIn = false; state.username = ''; state.notice = notice || '';   // hned, ať se odhlášení nespustí dvakrát
    destroyOverlay();
    if (webOn()) { webWin.destroy(); }
    webWin = null;
    try { await partitionSession().clearStorageData({ storages: ['cookies'] }); } catch (e) { /* nevadí */ }
    pushState();
    showControl();
}

/* ---------- okno aplikace (celý web jako v prohlížeči) ---------- */
function webUserAgent() {
    // Web pozná okno aplikace podle RedlineApp/ (ne RedlineOverlay/ – to je jen overlay): chová se jako běžný web + sekce „Aplikace“.
    return partitionSession().getUserAgent().replace(/\s*RedlineOverlay\/\S+/, '') + ' RedlineApp/' + app.getVersion();
}
function createWebWindow() {
    if (webOn()) { showWeb(); return; }
    const wa = screen.getPrimaryDisplay().workArea;
    const w = Math.min(1400, Math.round(wa.width * 0.88)), h = Math.min(900, Math.round(wa.height * 0.9));
    webWin = new BrowserWindow({
        width: w, height: h, minWidth: 380, minHeight: 520, title: 'RedLine MDT APP', autoHideMenuBar: true,
        backgroundColor: '#0b1020', icon: path.join(__dirname, 'icon.png'), show: false,
        webPreferences: { preload: path.join(__dirname, 'preload-web.js'), partition: PARTITION, contextIsolation: true, nodeIntegration: false, sandbox: true },
    });
    webWin.setMenu(null);
    const ua = webUserAgent();
    webWin.webContents.setUserAgent(ua);
    webWin.loadURL(siteUrl + '/index.php', { userAgent: ua });
    webWin.once('ready-to-show', () => { webWin.show(); webWin.focus(); pushMode(); });
    const sameSite = (url) => { try { return new URL(url).origin === new URL(siteUrl).origin; } catch (e) { return false; } };
    webWin.webContents.setWindowOpenHandler(({ url }) => {
        if (sameSite(url)) webWin.loadURL(url, { userAgent: ua }); else shell.openExternal(url);
        return { action: 'deny' };
    });
    webWin.webContents.on('will-navigate', (e, url) => { if (!sameSite(url)) { e.preventDefault(); shell.openExternal(url); } });
    // Odhlášení na webu / vypršelá relace -> zpět na přihlášení aplikace.
    const lostWeb = (url) => { if (state.loggedIn && /\/auth\/login\.php/.test(url)) doLogout(''); };
    webWin.webContents.on('did-navigate', (e, url) => lostWeb(url));
    webWin.webContents.on('did-redirect-navigation', (e, url) => lostWeb(url));
    // Křížek: bez overlaye aplikaci ukončí, s overlayem okno aplikace jen schová (ukončení je v menu overlaye).
    webWin.on('close', (e) => {
        if (quitting) return;
        if (overlayOn()) { e.preventDefault(); hideWeb(); }
        else { quitting = true; app.quit(); }
    });
    ['show', 'hide', 'minimize', 'restore'].forEach((ev) => webWin.on(ev, pushMode));
    webWin.on('closed', () => { webWin = null; });
}
function showWeb() {
    if (!state.loggedIn) { showControl(); return; }
    if (!webOn()) { createWebWindow(); return; }
    if (webWin.isMinimized()) webWin.restore();
    webWin.show(); webWin.focus();
    pushMode();
}
/** Schovat okno aplikace jde jen když běží overlay (jinak by nezbylo nic). */
function hideWeb() {
    if (!webOn() || !overlayOn()) return;
    webWin.hide();
    if (!overlayVisible) { overlayVisible = true; overlay.show(); }   // ať po schování okna zbyde aspoň overlay
    pushMode();
}
function setOverlay(on) {
    if (!state.loggedIn) return;
    if (on) { if (!overlayOn()) createOverlay(); }
    else { destroyOverlay(); if (!webShown()) showWeb(); }      // bez overlaye musí zůstat okno aplikace
    pushState();
}
function setAppShown(on) {
    if (on) showWeb(); else hideWeb();
}

/* ---------- overlay ---------- */
function destroyOverlay() {
    if (overlayOn()) overlay.destroy();
    overlay = null;
}
function createOverlay() {
    destroyOverlay();
    overlayVisible = true;
    const d = screen.getPrimaryDisplay();
    overlay = new BrowserWindow({
        x: d.bounds.x, y: d.bounds.y, width: d.bounds.width, height: d.bounds.height,
        transparent: true, frame: false, resizable: false, movable: false, hasShadow: false,
        icon: path.join(__dirname, 'icon.png'), skipTaskbar: true, alwaysOnTop: true, show: false, focusable: true, fullscreenable: false,
        webPreferences: { preload: path.join(__dirname, 'preload.js'), partition: PARTITION, contextIsolation: true, nodeIntegration: false },
    });
    overlay.setAlwaysOnTop(true, 'screen-saver');
    overlay.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: true });
    overlay.setIgnoreMouseEvents(true, { forward: true });
    overlay.loadURL(overlayUrl());
    overlay.once('ready-to-show', () => overlay.show());

    // Vypršelá relace (web přesměruje na přihlášení - i uvnitř oken mobilu / dispečinku) -> zpět na přihlášení.
    const lost = (url) => { if (state.loggedIn && /\/auth\/login\.php/.test(url)) doLogout('Přihlášení vypršelo – přihlas se znovu.'); };
    overlay.webContents.on('did-navigate', (e, url) => lost(url));
    overlay.webContents.on('did-redirect-navigation', (e, url) => lost(url));
    overlay.webContents.on('did-frame-navigate', (e, url) => lost(url));
    overlay.webContents.setWindowOpenHandler(({ url }) => { shell.openExternal(url); return { action: 'deny' }; });
    overlay.on('closed', () => { overlay = null; pushMode(); });
    overlay.webContents.on('did-finish-load', () => pushMode());
}

function sendHotkey(name) { if (state.loggedIn && overlay && !overlay.isDestroyed()) overlay.webContents.send('hotkey', name); }

function toggleOverlay() {
    if (!state.loggedIn || !overlay || overlay.isDestroyed()) return;
    overlayVisible = !overlayVisible;
    overlayVisible ? overlay.show() : overlay.hide();
}

/* ---------- tray ---------- */
function makeTrayIcon() { return nativeImage.createFromPath(path.join(__dirname, 'icon.png')).resize({ width: 16, height: 16 }); }

function refreshTray() {
    if (!tray) return;
    const items = [{ label: state.loggedIn ? 'Otevřít okno aplikace' : 'Otevřít okno přihlášení', click: showMain }];
    if (state.update && state.update.status === 'ready') items.push({ label: 'Restartovat a aktualizovat (verze ' + state.update.version + ')', click: installUpdate });
    items.push({ type: 'separator' });
    if (state.loggedIn) {
        items.push({ label: overlayOn() ? 'Vypnout overlay' : 'Zapnout overlay', click: () => setOverlay(!overlayOn()) });
        if (overlayOn()) {
            items.push(
                { label: webShown() ? 'Schovat okno aplikace' : 'Ukázat okno aplikace', click: () => setAppShown(!webShown()) },
                { type: 'separator' },
                { label: 'Ukázat / skrýt overlay (F7)', click: toggleOverlay },
                { label: 'Mobil (F8)', click: () => sendHotkey('phone') },
                { label: 'Dispečink (F9)', click: () => sendHotkey('disp') },
                { label: 'Znovu načíst overlay', click: () => overlay && !overlay.isDestroyed() && overlay.loadURL(overlayUrl()) },
            );
        }
        items.push({ type: 'separator' }, { label: 'Odhlásit se', click: () => doLogout('') });
    } else {
        items.push({ label: 'Přihlásit se…', click: showControl });
    }
    items.push({ type: 'separator' }, { label: 'Změnit adresu webu…', click: changeSite }, { label: 'Ukončit', click: () => app.quit() });
    tray.setContextMenu(Menu.buildFromTemplate(items));
    tray.setToolTip('RedLine MDT APP – ' + (state.loggedIn ? 'běží (' + state.username + (overlayOn() ? ', overlay zapnutý' : '') + ')' : 'nepřihlášen'));
}

function createTray() {
    tray = new Tray(makeTrayIcon());
    tray.on('click', () => { state.loggedIn && overlayOn() ? toggleOverlay() : showMain(); });
    tray.on('double-click', showMain);
    refreshTray();
}

function changeSite() {
    dialog.showMessageBox({
        type: 'info', title: 'Adresa webu',
        message: 'Aktuální adresa: ' + siteUrl,
        detail: 'Změníš ji v souboru config.json vedle programu, např.:\n{ "siteUrl": "https://tvuj-web.cz" }\nPak program restartuj.',
    });
}

/* ---------- IPC ---------- */
ipcMain.handle('app:init', () => {
    const c = loadCreds();
    return {
        username: c.username, hasSavedPassword: !!c.password, canEncrypt: canEncrypt(),
        state: { ...state, siteUrl }, version: app.getVersion(),
    };
});
ipcMain.handle('app:login', (e, data) => doLogin(data || {}));
ipcMain.handle('app:forget', () => { clearCreds(); return true; });
ipcMain.on('app:logout', () => { doLogout(''); });
ipcMain.on('app:install-update', installUpdate);
ipcMain.on('app:toggle-overlay', toggleOverlay);
// Ovládání režimů z webu (okno aplikace) a z menu overlaye – jen z našich oken
const ours = (e) => (webOn() && e.sender === webWin.webContents) || (overlayOn() && e.sender === overlay.webContents);
ipcMain.handle('mode:get', (e) => (ours(e) ? modeInfo() : null));
ipcMain.handle('mode:overlay', (e, on) => { if (!ours(e)) return null; setOverlay(!!on); return modeInfo(); });
ipcMain.handle('mode:app', (e, on) => { if (!ours(e)) return null; setAppShown(!!on); return modeInfo(); });
ipcMain.on('hook-status', (e) => { e.returnValue = hookOk; });
// Zkratky z webu (Nastavení): nahrazují původní; prázdný objekt = zkratky dočasně vypnuté (třeba při nastavování nové)
ipcMain.on('set-hotkeys', (e, k) => {
    const clean = {};
    if (k && typeof k === 'object') {
        for (const key of ['phone', 'win', 'menu', 'radio', 'ptt']) {
            if (typeof k[key] === 'string' && /^[A-Za-z0-9]{1,20}$/.test(k[key])) clean[key] = k[key];
        }
    }
    hotkeys = clean;
    if (pttHeldBy.token && tokenOf(hotkeys.ptt) !== pttHeldBy.token) { pttHeldBy.token = null; sendHotkey('ptt-up'); }
});
ipcMain.on('app:hotkey', (e, name) => { if (name === 'phone' || name === 'disp') sendHotkey(name); });
ipcMain.on('app:minimize', () => { if (controlWin && !controlWin.isDestroyed()) controlWin.minimize(); });
ipcMain.on('app:quit', () => app.quit());

// Přepínání průchodu myši z webu (okno jen nad mobilem / dispečinkem zachytává myš)
ipcMain.on('set-ignore', (e, ignore) => {
    if (!overlay || overlay.isDestroyed()) return;
    overlay.setIgnoreMouseEvents(!!ignore, { forward: true });
});
// Klik kamkoliv do našich oken (celý mobil, dispečink, menu, nastavení - i do obsahu uvnitř rámů) = aplikace je v popředí
ipcMain.on('focus-overlay', () => {
    if (!overlay || overlay.isDestroyed() || !overlay.isVisible()) return;
    try {
        if (!overlay.isFocused()) overlay.focus();
        overlay.moveTop();
        overlay.webContents.focus();
    } catch (e) { /* okno se právě zavírá */ }
});
ipcMain.on('quit', () => app.quit());

/* ---------- start ---------- */
const gotLock = app.requestSingleInstanceLock();
if (!gotLock) { app.quit(); } else {
    app.setAppUserModelId('cz.redline.overlay');
    app.on('second-instance', () => { showMain(); });
    app.whenReady().then(async () => {
        loadConfig();
        const ses = partitionSession();
        // Web pozná aplikaci podle User-Agentu (overlay a skrytý dispečink v mobilu fungují jen v ní).
        ses.setUserAgent(ses.getUserAgent() + ' RedlineOverlay/' + app.getVersion());
        // Po každém spuštění se musí přihlásit znovu - staré cookies pryč.
        try { await ses.clearStorageData({ storages: ['cookies'] }); } catch (e) { /* nevadí */ }
        createControl();
        createTray();
        globalShortcut.register('F7', toggleOverlay);
        startHook();
        setupUpdater();
        if (!hookOk) {   // bez uiohook aspoň F8 / F9 jako dřív (zbytek zkratek jen v zaměřeném okně)
            globalShortcut.register('F8', () => sendHotkey('phone'));
            globalShortcut.register('F9', () => sendHotkey('disp'));
        }
    });
    app.on('before-quit', () => { quitting = true; });
    app.on('will-quit', () => { globalShortcut.unregisterAll(); try { uIOhook && hookOk && uIOhook.stop(); } catch (e) { /* konec */ } });
    app.on('window-all-closed', () => { /* běží dál v liště a na hlavním panelu */ });
}
